-------------------------------SECTION A ------------------------------
-----------TASK 1------------
CREATE SCHEMA IF NOT EXISTS partition_lab;
SET search_path TO partition_lab;
-----------TASK 2------------
DROP TABLE IF EXISTS fact_sales_base;

CREATE TABLE fact_sales_base (
    sales_key INT,
    date_key DATE,
    customer_key INT,
	product_key INT,
    quantity INT,
	revenue_usd  NUMERIC,
    channel TEXT
);

-------------------------------SECTION B ------------------------------
-----------TASK 1------------

--1.
DROP TABLE IF EXISTS fact_sales_horz;

CREATE TABLE fact_sales_horz (
    sales_key INT,
    date_key DATE,
	customer_key INT,
    product_key INT,
    quantity INT,
	revenue_usd NUMERIC,
    channel TEXT
) PARTITION BY RANGE (EXTRACT(YEAR FROM date_key));

--2.
CREATE TABLE fact_sales_2023 PARTITION OF fact_sales_horz
    FOR VALUES FROM (2023) TO (2024);

CREATE TABLE fact_sales_2024 PARTITION OF fact_sales_horz
    FOR VALUES FROM (2024) TO (2025);

--3.
INSERT INTO fact_sales_horz
SELECT * FROM fact_sales_base;

--4.
EXPLAIN ANALYZE
SELECT SUM (revenue_usd)
FROM fact_sales_horz
WHERE date_key BETWEEN '20230101' AND '20231231';

-----------TASK 2------------
--5.
DROP TABLE IF EXISTS fact_sales_list;

CREATE TABLE fact_sales_list (
    sales_key INT,
    date_key DATE,
    customer_key INT,
	product_key INT,
    quantity INT,
	revenue_usd  NUMERIC,
    channel TEXT
) PARTITION BY LIST (channel);

CREATE TABLE fact_sales_online PARTITION OF fact_sales_list
    FOR VALUES IN ('Online');

CREATE TABLE fact_sales_store PARTITION OF fact_sales_list
    FOR VALUES IN ('In-Store');

INSERT INTO fact_sales_list
SELECT * FROM fact_sales_base;

--6.
EXPLAIN ANALYZE
SELECT SUM(revenue_usd)
FROM fact_sales_list WHERE channel = 'Online';

-----------TASK 3------------
--7.
DROP TABLE IF EXISTS fact_sales_hash;

CREATE TABLE fact_sales_hash (
    sales_key INT,
    date_key DATE,
    customer_key INT,
	product_key INT,
    quantity INT,
	revenue_usd  NUMERIC,
    channel TEXT
) PARTITION BY HASH (customer_key);

CREATE TABLE fact_sales_h0 PARTITION OF fact_sales_hash FOR VALUES WITH (modulus 4, remainder 0);
CREATE TABLE fact_sales_h1 PARTITION OF fact_sales_hash FOR VALUES WITH (modulus 4, remainder 1);
CREATE TABLE fact_sales_h2 PARTITION OF fact_sales_hash FOR VALUES WITH (modulus 4, remainder 2);
CREATE TABLE fact_sales_h3 PARTITION OF fact_sales_hash FOR VALUES WITH (modulus 4, remainder 3);

INSERT INTO fact_sales_hash
SELECT * FROM fact_sales_base;

--8.
SELECT 'h0', COUNT(*) FROM fact_sales_h0
UNION ALL
SELECT 'h1', COUNT(*) FROM fact_sales_h1
UNION ALL
SELECT 'h2', COUNT(*) FROM fact_sales_h2
UNION ALL
SELECT 'h3', COUNT(*) FROM fact_sales_h3;

-------------------------------SECTION C ------------------------------
CREATE TABLE temp_products (
    product_key INT PRIMARY KEY,
    product_name TEXT,
    category TEXT,
    price_usd NUMERIC
);

--9.
-------- HOT TABLE QUERIES 
CREATE TABLE product_hot (
    product_key INT PRIMARY KEY,
    category TEXT,
   price_usd NUMERIC
);
-------- COLD TABLE
CREATE TABLE product_cold (
    product_key INT PRIMARY KEY REFERENCES product_hot(product_key),
    product_name TEXT
);

INSERT INTO product_hot
SELECT product_key, category, price_usd
FROM temp_products;

INSERT INTO product_cold
SELECT product_key, product_name
FROM temp_products;

--10.
------- HOT QUERY 
EXPLAIN ANALYZE
SELECT category, AVG(price_usd)
FROM product_hot 
GROUP BY category;

--------COLD QUERY
EXPLAIN ANALYZE
SELECT ph.category, pc.product_name
FROM product_hot ph
JOIN product_cold pc USING (product_key);

-------------------------------SECTION D ------------------------------
--11.
EXPLAIN ANALYZE
SELECT * FROM fact_sales_horz
WHERE sales_key = 155;

--12.
EXPLAIN ANALYZE
SELECT customer_key, SUM(revenue_usd)
FROM fact_sales_horz
GROUP BY customer_key;
