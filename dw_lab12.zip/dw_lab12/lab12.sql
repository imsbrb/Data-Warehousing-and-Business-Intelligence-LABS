-- =========================================================
-- SECTION A - BRONZE LAYER (RAW DATA INGESTION)
-- =========================================================

-- Q1. Create schemas for lakehouse simulation
CREATE SCHEMA IF NOT EXISTS bronze;
CREATE SCHEMA IF NOT EXISTS silver;
CREATE SCHEMA IF NOT EXISTS gold;

-- Q2. Create raw (bronze) tables
DROP TABLE IF EXISTS bronze.dim_customer_raw;
CREATE TABLE bronze.dim_customer_raw (
    customer_key    TEXT,
    customer_name   TEXT,
    region          TEXT,
    loyalty_tier    TEXT
);

DROP TABLE IF EXISTS bronze.dim_product_raw;
CREATE TABLE bronze.dim_product_raw (
    product_key     TEXT,
    product_name    TEXT,
    category        TEXT,
    price_usd       TEXT
);

DROP TABLE IF EXISTS bronze.dim_date_raw;
CREATE TABLE bronze.dim_date_raw (
    date_key    TEXT,
    full_date   TEXT,
    day         TEXT,
    month       TEXT,
    year        TEXT
);

DROP TABLE IF EXISTS bronze.fact_sales_raw;
CREATE TABLE bronze.fact_sales_raw (
    sales_key   TEXT,
    date_key    TEXT,
    customer_key TEXT,
    product_key TEXT,
    quantity    TEXT,
    revenue_usd TEXT,
    channel     TEXT
);
-- Q3. Validate Bronze Data (just sample queries; run them one by one)

-- 3.1 Row counts
SELECT 'dim_customer_raw' AS table_name, COUNT(*) FROM bronze.dim_customer_raw;
SELECT 'dim_product_raw'  AS table_name, COUNT(*) FROM bronze.dim_product_raw;
SELECT 'dim_date_raw'     AS table_name, COUNT(*) FROM bronze.dim_date_raw;
SELECT 'fact_sales_raw'   AS table_name, COUNT(*) FROM bronze.fact_sales_raw;

-- 3.2 Null checks

SELECT COUNT(*) FROM bronze.fact_sales_raw WHERE sales_key IS NULL;

-- 3.3 Duplicate rows
SELECT sales_key, COUNT(*) FROM bronze.fact_sales_raw
GROUP BY sales_key HAVING COUNT(*) > 1;

-- 3.4 Data type issues (examples)
SELECT * FROM bronze.fact_sales_raw WHERE quantity ~ '[^0-9]';
SELECT * FROM bronze.fact_sales_raw WHERE revenue_usd ~ '[^0-9\.]';

SELECT * FROM bronze.dim_customer_raw LIMIT 20;
SELECT * FROM bronze.dim_product_raw LIMIT 20;
SELECT * FROM bronze.dim_date_raw LIMIT 20;
SELECT * FROM bronze.fact_sales_raw LIMIT 20;


-- =========================================================
-- SECTION B - SILVER LAYER (CLEANED, STANDARDIZED)
-- =========================================================

-- ----------------------------
-- silver.dim_customer
-- ----------------------------
DROP TABLE IF EXISTS silver.dim_customer;
CREATE TABLE silver.dim_customer AS
SELECT DISTINCT
    CAST(TRIM(customer_key) AS INTEGER)           AS customer_key,
    TRIM(customer_name)                           AS customer_name,
    INITCAP(TRIM(region))                         AS region,        -- normalize case
    LOWER(TRIM(loyalty_tier))                     AS loyalty_tier   -- e.g. "bronze", "silver"
FROM bronze.dim_customer_raw
WHERE customer_key IS NOT NULL
  AND customer_key ~ '^[0-9]+$';  -- keep only numeric keys

-- Enforce basic types/constraints
ALTER TABLE silver.dim_customer
    ALTER COLUMN customer_key SET NOT NULL;

CREATE UNIQUE INDEX idx_silver_dim_customer_key
    ON silver.dim_customer(customer_key);


-- ----------------------------
-- silver.dim_product
-- ----------------------------
DROP TABLE IF EXISTS silver.dim_product;
CREATE TABLE silver.dim_product AS
SELECT DISTINCT
    CAST(TRIM(product_key) AS INTEGER)                    AS product_key,
    TRIM(product_name)                                    AS product_name,
    INITCAP(TRIM(category))                               AS category,
    CAST(NULLIF(TRIM(price_usd), '') AS NUMERIC(12,2))    AS price_usd
FROM bronze.dim_product_raw
WHERE product_key IS NOT NULL
  AND product_key ~ '^[0-9]+$';

ALTER TABLE silver.dim_product
    ALTER COLUMN product_key SET NOT NULL;

CREATE UNIQUE INDEX idx_silver_dim_product_key
    ON silver.dim_product(product_key);


-- ----------------------------
-- silver.dim_date
-- ----------------------------
DROP TABLE IF EXISTS silver.dim_date;
CREATE TABLE silver.dim_date AS
SELECT DISTINCT
    CAST(TRIM(date_key) AS INTEGER)                       AS date_key,
    CAST(TRIM(full_date) AS DATE)                         AS full_date,
    CAST(TRIM(day) AS INTEGER)                            AS day,
    CAST(TRIM(month) AS INTEGER)                          AS month,
    CAST(TRIM(year) AS INTEGER)                           AS year
FROM bronze.dim_date_raw
WHERE date_key IS NOT NULL
  AND date_key ~ '^[0-9]+$'
  AND full_date IS NOT NULL
  AND full_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$';

ALTER TABLE silver.dim_date
    ALTER COLUMN date_key SET NOT NULL;

CREATE UNIQUE INDEX idx_silver_dim_date_key
    ON silver.dim_date(date_key);


-- ----------------------------
-- silver.fact_sales_clean
-- ----------------------------
DROP TABLE IF EXISTS silver.fact_sales_clean;
CREATE TABLE silver.fact_sales_clean AS
WITH cleaned AS (
    SELECT
        TRIM(sales_key)     AS sales_key_raw,
        TRIM(date_key)      AS date_key_raw,
        TRIM(customer_key)  AS customer_key_raw,
        TRIM(product_key)   AS product_key_raw,
        TRIM(quantity)      AS quantity_raw,
        TRIM(revenue_usd)   AS revenue_usd_raw,
        LOWER(TRIM(channel)) AS channel_clean
    FROM bronze.fact_sales_raw
)
SELECT DISTINCT
    CAST(CAST(sales_key_raw AS NUMERIC) AS BIGINT)       AS sales_key,
    CAST(CAST(date_key_raw AS NUMERIC) AS INTEGER)       AS date_key,
    CAST(CAST(customer_key_raw AS NUMERIC) AS INTEGER)   AS customer_key,
    CAST(CAST(product_key_raw AS NUMERIC) AS INTEGER)    AS product_key,
    CAST(CAST(quantity_raw AS NUMERIC) AS INTEGER)       AS quantity,
    CAST(CAST(revenue_usd_raw AS NUMERIC) AS NUMERIC(14,2)) AS revenue_usd,
    channel_clean                                        AS channel
FROM cleaned
WHERE sales_key_raw IS NOT NULL
  AND date_key_raw IS NOT NULL
  AND customer_key_raw IS NOT NULL
  AND product_key_raw IS NOT NULL;


SELECT * FROM silver.dim_customer LIMIT 20;
SELECT * FROM silver.dim_product  LIMIT 20;
SELECT * FROM silver.dim_date  LIMIT 20;
SELECT * FROM silver.fact_sales_clean LIMIT 20;

-- =========================================================
-- SECTION C - GOLD LAYER (DW / AGGREGATED LAYER)
-- =========================================================

-- Q8. Build Dimension Tables in Gold Layer (with surrogate keys)

-- ----------------------------
-- gold.dim_customer
-- ----------------------------
DROP TABLE IF EXISTS gold.dim_customer;
CREATE TABLE gold.dim_customer (
    customer_sk   SERIAL PRIMARY KEY,
    customer_key  INTEGER NOT NULL,
    customer_name TEXT,
    region        TEXT,
    loyalty_tier  TEXT
);

INSERT INTO gold.dim_customer (customer_key, customer_name, region, loyalty_tier)
SELECT
    customer_key,
    customer_name,
    region,
    loyalty_tier
FROM silver.dim_customer;

CREATE UNIQUE INDEX idx_gold_dim_customer_nk
    ON gold.dim_customer(customer_key);


-- ----------------------------
-- gold.dim_product
-- ----------------------------
DROP TABLE IF EXISTS gold.dim_product;
CREATE TABLE gold.dim_product (
    product_sk    SERIAL PRIMARY KEY,
    product_key   INTEGER NOT NULL,
    product_name  TEXT,
    category      TEXT,
    price_usd     NUMERIC(12,2)
);

INSERT INTO gold.dim_product (product_key, product_name, category, price_usd)
SELECT
    product_key,
    product_name,
    category,
    price_usd
FROM silver.dim_product;

CREATE UNIQUE INDEX idx_gold_dim_product_nk
    ON gold.dim_product(product_key);


-- ----------------------------
-- gold.dim_date
-- ----------------------------
DROP TABLE IF EXISTS gold.dim_date;
CREATE TABLE gold.dim_date (
    date_sk   SERIAL PRIMARY KEY,
    date_key  INTEGER NOT NULL,
    full_date DATE,
    day       INTEGER,
    month     INTEGER,
    year      INTEGER
);

INSERT INTO gold.dim_date (date_key, full_date, day, month, year)
SELECT
    date_key,
    full_date,
    day,
    month,
    year
FROM silver.dim_date;

CREATE UNIQUE INDEX idx_gold_dim_date_nk
    ON gold.dim_date(date_key);


-- Q9. Build Gold Fact Table (star schema)

DROP TABLE IF EXISTS gold.fact_sales;
CREATE TABLE gold.fact_sales (
    fact_sk      SERIAL PRIMARY KEY,
    sales_key    BIGINT NOT NULL,
    date_sk      INTEGER NOT NULL,
    customer_sk  INTEGER NOT NULL,
    product_sk   INTEGER NOT NULL,
    quantity     INTEGER,
    revenue_usd  NUMERIC(14,2),
    channel      TEXT,
    CONSTRAINT fk_fact_date    FOREIGN KEY (date_sk)     REFERENCES gold.dim_date(date_sk),
    CONSTRAINT fk_fact_customer FOREIGN KEY (customer_sk) REFERENCES gold.dim_customer(customer_sk),
    CONSTRAINT fk_fact_product FOREIGN KEY (product_sk)  REFERENCES gold.dim_product(product_sk)
);

INSERT INTO gold.fact_sales (
    sales_key, date_sk, customer_sk, product_sk,
    quantity, revenue_usd, channel
)
SELECT
    fs.sales_key,
    d.date_sk,
    c.customer_sk,
    p.product_sk,
    fs.quantity,
    fs.revenue_usd,
    fs.channel
FROM silver.fact_sales_clean fs
JOIN gold.dim_date d
    ON fs.date_key = d.date_key
JOIN gold.dim_customer c
    ON fs.customer_key = c.customer_key
JOIN gold.dim_product p
    ON fs.product_key = p.product_key;

CREATE UNIQUE INDEX idx_gold_fact_sales_sales_key
    ON gold.fact_sales(sales_key);


-- Q10. Build a Gold Aggregate Table

DROP TABLE IF EXISTS gold.agg_monthly_region_category;
CREATE TABLE gold.agg_monthly_region_category AS
SELECT
    dd.year,
    dd.month,
    dc.region,
    dp.category,
    SUM(fs.revenue_usd) AS total_revenue_usd,
    SUM(fs.quantity)    AS total_quantity
FROM gold.fact_sales fs
JOIN gold.dim_date dd      ON fs.date_sk = dd.date_sk
JOIN gold.dim_customer dc  ON fs.customer_sk = dc.customer_sk
JOIN gold.dim_product dp   ON fs.product_sk = dp.product_sk
GROUP BY
    dd.year,
    dd.month,
    dc.region,
    dp.category;

-- Optional index for faster BI queries
CREATE INDEX idx_gold_agg_mrc_ymrc
    ON gold.agg_monthly_region_category(year, month, region, category);

select * from gold.fact_sales

-- =========================================================
-- SECTION D - DELTA-LIKE BEHAVIOR (ACID & VERSIONING)
-- =========================================================

-- Q11. Implement a MERGE (Upsert) Operation
-- Staging table (could be from another CSV)
DROP TABLE IF EXISTS silver.fact_sales_incremental;
CREATE TABLE silver.fact_sales_incremental AS
SELECT * FROM silver.fact_sales_clean


-- MERGE into gold.fact_sales using PostgreSQL 15+ syntax
INSERT INTO gold.fact_sales
    (sales_key, date_sk, customer_sk, product_sk, quantity, revenue_usd, channel)
SELECT
    i.sales_key,
    d.date_sk,
    c.customer_sk,
    p.product_sk,
    i.quantity,
    i.revenue_usd,
    i.channel
FROM silver.fact_sales_incremental i
JOIN gold.dim_date d
    ON i.date_key = d.date_key
JOIN gold.dim_customer c
    ON i.customer_key = c.customer_key
JOIN gold.dim_product p
    ON i.product_key = p.product_key
ON CONFLICT (sales_key)
DO UPDATE SET
    date_sk     = EXCLUDED.date_sk,
    customer_sk = EXCLUDED.customer_sk,
    product_sk  = EXCLUDED.product_sk,
    quantity    = EXCLUDED.quantity,
    revenue_usd = EXCLUDED.revenue_usd,
    channel     = EXCLUDED.channel;

	
SELECT * FROM silver.fact_sales_incremental
-- Q12. Create a History Table for “Time Travel” Simulation

DROP TABLE IF EXISTS gold.fact_sales_history;
CREATE TABLE gold.fact_sales_history (
    snapshot_ts TIMESTAMP NOT NULL DEFAULT NOW(),
    fact_sk     INTEGER,
    sales_key   BIGINT,
    date_sk     INTEGER,
    customer_sk INTEGER,
    product_sk  INTEGER,
    quantity    INTEGER,
    revenue_usd NUMERIC(14,2),
    channel     TEXT
);

-- Take initial snapshot BEFORE some updates
INSERT INTO gold.fact_sales_history (
    snapshot_ts, fact_sk, sales_key, date_sk, customer_sk, product_sk,
    quantity, revenue_usd, channel
)
SELECT
    NOW() AS snapshot_ts,
    fact_sk,
    sales_key,
    date_sk,
    customer_sk,
    product_sk,
    quantity,
    revenue_usd,
    channel
FROM gold.fact_sales;

-- (Run some MERGE/UPDATE/DELETE operations here…)

-- Take another snapshot AFTER changes
INSERT INTO gold.fact_sales_history (
    snapshot_ts, fact_sk, sales_key, date_sk, customer_sk, product_sk,
    quantity, revenue_usd, channel
)
SELECT
    NOW() AS snapshot_ts,
    fact_sk,
    sales_key,
    date_sk,
    customer_sk,
    product_sk,
    quantity,
    revenue_usd,
    channel
FROM gold.fact_sales;

select * from gold.fact_sales_history


-- Q13. Retrieve Previous Versions (“time travel”-like query)
SELECT *
FROM gold.fact_sales_history h
WHERE h.snapshot_ts = (
   SELECT MAX(snapshot_ts)
   FROM gold.fact_sales_history
   WHERE snapshot_ts <= TIMESTAMP '"2025-12-08 21:03:52.144343"'
);


-- Q14. Schema Evolution Simulation


-- 1) Evolve Bronze schema
ALTER TABLE bronze.dim_customer_raw
    ADD COLUMN email TEXT;

-- 2) Evolve Silver schema 
ALTER TABLE silver.dim_customer
    ADD COLUMN email TEXT;

-- 3) Evolve Gold dimension
ALTER TABLE gold.dim_customer
    ADD COLUMN email TEXT;
