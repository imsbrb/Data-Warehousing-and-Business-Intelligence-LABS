DROP SCHEMA IF EXISTS dw_lab CASCADE;
CREATE SCHEMA dw_lab;
SET search_path= dw_lab,public;


CREATE TABLE regions_oltp(
region_id    integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
region_name  text NOT NULL
);

CREATE TABLE customers_oltp(
customer_id  integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
customer_name text NOT NULL,
region_id     integer NOT NULL REFERENCES regions_oltp(region_id),
signup_date   date NOT NULL
);

CREATE TABLE products_oltp(
product_id    integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
product_name   text NOT NULL,
category       text NOT NULL,
unit_price      numeric(12,2) NOT NULL
);

CREATE TABLE orders_oltp(
order_id      integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
customer_id   integer NOT NULL REFERENCES customers_oltp(customer_id),
order_ts      timestamp NOT NULL
);

CREATE TABLE order_items_oltp(
order_item_id  integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
order_id       integer NOT NULL REFERENCES orders_oltp(order_id),
product_id     integer NOT NULL REFERENCES products_oltp(product_id),
quantity       integer NOT NULL CHECK (quantity > 0),
unit_price     numeric(12,2) NOT NULL
);

TRUNCATE TABLE regions_oltp,customers_oltp,products_oltp,orders_oltp,order_items_oltp
RESTART IDENTITY;

--TASK 4
SELECT SUM(quantity * unit_price) AS total_revenue
FROM order_items_oltp;


--PART B 

CREATE TABLE dim_date (
    date_key INTEGER PRIMARY KEY,
    full_date DATE,
    day_of_week INTEGER,
    month INTEGER,
    month_name TEXT,
    quarter INTEGER,
    year INTEGER
);


TRUNCATE TABLE dim_date
RESTART IDENTITY;

WITH bounds AS (
    SELECT MIN(order_ts)::date AS min_d, MAX(order_ts)::date AS max_d FROM orders_oltp
),
series AS (
    SELECT g::date AS d FROM bounds, generate_series(min_d, max_d, interval '1 day') g
)
INSERT INTO dim_date 
SELECT 
    (EXTRACT(YEAR FROM d)::int * 10000 + EXTRACT(MONTH FROM d)::int * 100 + EXTRACT(DAY FROM d)::int),
	d,
    EXTRACT(ISODOW FROM d)::int,
    EXTRACT(MONTH FROM d)::int,
    TO_CHAR(d, 'Mon'),
    EXTRACT(QUARTER FROM d)::int,
    EXTRACT(YEAR FROM d)::int
FROM series;

--TASK 1.2
select * from dim_date

--TASK 2
CREATE TABLE dim_product (
    product_key SERIAL PRIMARY KEY,  -- Surrogate key
    product_id INTEGER,              -- Natural key
    product_name TEXT,
    category TEXT,
    unit_price  numeric(12,2) NOT NULL
);
INSERT INTO dim_product (product_id, product_name, category, unit_price)
SELECT product_id, product_name, category, unit_price
FROM products_oltp;

SELECT * FROM dim_product ;

--TASK 3 
CREATE TABLE dim_customer (
    customer_key SERIAL PRIMARY KEY,  -- Surrogate key
    customer_id INTEGER,              -- Natural key
    customer_name TEXT,
    region_id INTEGER,
    signup_date date NOT NULL
);

INSERT INTO dim_customer (customer_id, customer_name, region_id, signup_date)
SELECT 
    c.customer_id,
    c.customer_name,
    c.region_id,
    c.signup_date
FROM customers_oltp c

SELECT * FROM dim_customer ;

--TASK 4
CREATE TABLE fact_sales (
    date_key INTEGER REFERENCES dim_date(date_key),
    product_key INTEGER REFERENCES dim_product(product_key),
    customer_key INTEGER REFERENCES dim_customer(customer_key),
    order_id_src INTEGER,
    quantity INTEGER,
    unit_price NUMERIC(12,2),
    revenue NUMERIC(18,2)
);

INSERT INTO fact_sales (
    date_key, product_key, customer_key, order_id_src, quantity, unit_price, revenue
)
SELECT
    -- Convert order_ts to date_key format
    EXTRACT(YEAR FROM o.order_ts)::int * 10000 +
    EXTRACT(MONTH FROM o.order_ts)::int * 100 +
    EXTRACT(DAY FROM o.order_ts)::int AS date_key,

    -- Get product_key from dim_product
    dp.product_key,

    -- Get customer_key from dim_customer
    dc.customer_key,

    -- Original order ID
    o.order_id,

    -- Quantity and unit price from order_items
    i.quantity,
    i.unit_price,

    -- Calculate revenue
    (i.quantity * i.unit_price)::numeric(18,2) 

FROM order_items_oltp i
JOIN orders_oltp o ON o.order_id = i.order_id
JOIN dim_product dp ON dp.product_id = i.product_id
JOIN dim_customer dc ON dc.customer_id = o.customer_id;

SELECT * FROM fact_sales ;


--TASK 5
WITH olap as (select sum(revenue)::numeric (18,2)as fact_rev from fact_sales),
     oltp as (select sum (quantity*unit_price)::numeric(18,2)as det_rev from order_items_oltp)
select * from olap cross join oltp;	 


---------------------------------PART C-----------------------------------
--TASK 1
CREATE TABLE fact_sales_wide AS
SELECT
    -- Fact table fields
    fs.order_id_src,
    fs.quantity,
    fs.unit_price,
    fs.revenue,

    -- Date dimension fields
    dd.full_date,
    dd.day_of_week,
    dd.month,
    dd.month_name,
    dd.quarter,
    dd.year,

    -- Product dimension fields
    dp.product_name,
    dp.category,
    dp.unit_price AS product_unit_price,

    -- Customer dimension fields
    dc.customer_name,
    dc.region_id,
    dc.signup_date

FROM fact_sales fs
JOIN dim_date dd ON fs.date_key = dd.date_key
JOIN dim_product dp ON fs.product_key = dp.product_key
JOIN dim_customer dc ON fs.customer_key = dc.customer_key;


SELECT
    (SELECT COUNT(*) FROM fact_sales) AS fact_sales_count,
    (SELECT COUNT(*) FROM fact_sales_wide) AS fact_sales_wide_count,
    (SELECT SUM(revenue)::numeric(18,2) FROM fact_sales) AS fact_sales_revenue,
    (SELECT SUM(revenue)::numeric(18,2) FROM fact_sales_wide) AS fact_sales_wide_revenue;
--TASK 2
ALTER TABLE dim_product
ADD COLUMN default_region TEXT;

UPDATE dim_product
SET default_region = sub.region_name
FROM (
    SELECT DISTINCT ON (fs.product_key)
        fs.product_key,
        r.region_name
    FROM fact_sales fs
    JOIN dim_customer dc ON fs.customer_key = dc.customer_key
    JOIN regions_oltp r ON dc.region_id = r.region_id
    ORDER BY fs.product_key, fs.order_id_src
) sub
WHERE dim_product.product_key = sub.product_key;

SELECT 
  default_region, 
  COUNT(*) AS product_count
FROM dim_product
GROUP BY default_region
ORDER BY product_count DESC;

--Task 3
CREATE TABLE agg_sales_m_cat_region AS
SELECT
    make_date(dd.year::int, dd.month::int, 1) AS month_start,
    dp.category,
    r.region_name,
    SUM(fs.revenue)::numeric(18,2) AS total_revenue,
    SUM(fs.quantity) AS total_units,
    COUNT(DISTINCT fs.order_id_src) AS distinct_orders
FROM fact_sales fs
JOIN dim_date dd ON fs.date_key = dd.date_key
JOIN dim_product dp ON fs.product_key = dp.product_key
JOIN dim_customer dc ON fs.customer_key = dc.customer_key
JOIN regions_oltp r ON dc.region_id = r.region_id
GROUP BY month_start, dp.category, r.region_name
ORDER BY month_start, dp.category, r.region_name;

SELECT 
  month_start,
  category,
  region_name,
  total_revenue AS revenue,
  total_units AS units,
  distinct_orders AS orders
FROM agg_sales_m_cat_region

ORDER BY category, region_name;
