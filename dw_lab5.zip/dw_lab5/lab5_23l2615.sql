DROP SCHEMA IF EXISTS staging  CASCADE;
DROP SCHEMA IF EXISTS dw CASCADE;
CREATE SCHEMA staging;
CREATE SCHEMA dw;

CREATE TABLE staging.stg_customers(
customer_id text,
customer_name text,
region text,
signup_date text
);

CREATE TABLE staging.stg_products(
product_id  text,
product_name text,
category   text,
unit_price   text
);

CREATE TABLE staging.stg_order(
order_id  text,
cutomer_id  text,
order_date  text
);

CREATE TABLE staging.stg_order_items(
order_item_id  text,
order_id   text,
product_id   text,
quantity   text,
unit_price  text
);
---------TASK 4-----------
-- Count rows in each staging table
SELECT COUNT(*) AS total_customers FROM staging.stg_customers;
SELECT COUNT(*) AS total_products FROM staging.stg_products;
SELECT COUNT(*) AS order_id FROM staging.stg_order;
SELECT COUNT(*) AS order_item_id FROM staging.stg_order_items;

-- Check for NULLs in primary key fields
SELECT COUNT(*) AS null_customer_ids FROM staging.stg_customers WHERE customer_id IS NULL;
SELECT COUNT(*) AS null_product_ids FROM staging.stg_products WHERE product_id IS NULL;
SELECT COUNT(*) AS null_order_ids FROM staging.stg_order WHERE order_id IS NULL;
SELECT COUNT(*) AS null_order_item_ids FROM staging.stg_order_items WHERE order_item_id IS NULL;

---------------------STEP 2---------------------
CREATE TABLE dw.dim_customer(
customer_key   SERIAL PRIMARY KEY,
customer_id   int UNIQUE,
customer_name  text,
region_name  text,
signup_date  date
);

INSERT INTO dw.dim_customer(customer_id,customer_name,region_name,signup_date)
SELECT DISTINCT ON (customer_id)
       customer_id::int,
	   INITCAP(customer_name),
	   UPPER (region),
	   signup_date::date
FROM staging.stg_customers
ORDER BY customer_id,signup_date DESC;

-------TASK 2------
CREATE TABLE dw.dim_product(
product_key  SERIAL PRIMARY KEY,
product_id   int UNIQUE,
product_name  text,
category   text,
unit_price  numeric(12,2)
);
INSERT INTO dw.dim_product(product_id,product_name,category,unit_price)
SELECT product_id::int,
       INITCAP (product_name),
	   UPPER (LEFT(category,1)),
	   CASE WHEN unit_price::numeric<=0  THEN 10.00 ELSE unit_price::numeric END
FROM staging.stg_products;

-------TASK 3------
CREATE TABLE dw.dim_date(
date_key   int PRIMARY KEY ,
full_date  date,
day_of_week int,
month_num   int,
month_name  text,
quater_num int,
year_num   int
);
INSERT INTO dw.dim_date
SELECT DISTINCT 
   TO_CHAR(order_date::date,'YYYYMMDD')::int AS date_key,
   order_date::date,
   EXTRACT (ISODOW FROM order_date::date)::int,
   EXTRACT (MONTH FROM order_date::date)::int,
   TO_CHAR(order_date::date,'Mon'),
   EXTRACT (QUARTER FROM order_date::date)::int,
   EXTRACT(YEAR  FROM order_date::date)::int
FROM staging.stg_order;


-----------------------STEP 3-----------------
-------TASK1-------
CREATE TABLE dw.fact_sales (
    fact_id SERIAL PRIMARY KEY,
    date_key INT REFERENCES dw.dim_date(date_key),
    product_key INT REFERENCES dw.dim_product(product_key),
    customer_key INT REFERENCES dw.dim_customer(customer_key),
    order_id INT,
    quantity INT,
    unit_price NUMERIC(12,2),
    revenue NUMERIC(18,2)
);
--------TASK 2------
INSERT INTO dw.fact_sales (
    date_key, product_key, customer_key, order_id, quantity, unit_price, revenue
)
SELECT 
    TO_CHAR(o.order_date::date, 'YYYYMMDD')::int AS date_key,
    dp.product_key,
    dc.customer_key,
    o.order_id::int,
    oi.quantity::int,
    oi.unit_price::numeric(12,2),
    (oi.quantity::int * oi.unit_price::numeric(12,2))::numeric(18,2) AS revenue
FROM staging.stg_order_items oi
JOIN staging.stg_order o ON oi.order_id = o.order_id
JOIN dw.dim_product dp ON dp.product_id = oi.product_id::int
JOIN dw.dim_customer dc ON dc.customer_id = o.cutomer_id::int;

--------TASK 3-----
-- Total revenue from fact_sales
SELECT SUM(revenue) AS dw_revenue FROM dw.fact_sales;

-- Total revenue from staging order_items
SELECT SUM(quantity::int * unit_price::numeric(12,2))::numeric(18,2) AS staging_revenue
FROM staging.stg_order_items;


--------------------------------PART C--------------------
-------STEP 1------
DROP TABLE IF EXISTS dw.raw_sales;
CREATE TABLE dw.raw_sales AS
SELECT * FROM staging.stg_order_items;

SELECT COUNT(*) AS raw_sales_rows FROM dw.raw_sales;

-----STEP 2-----
DROP TABLE IF EXISTS dw.fact_sales_elt;
CREATE TABLE dw.fact_sales_elt (
    fact_id SERIAL PRIMARY KEY,
    date_key INT REFERENCES dw.dim_date(date_key),
    product_key INT REFERENCES dw.dim_product(product_key),
    customer_key INT REFERENCES dw.dim_customer(customer_key),
    order_id INT,
    quantity INT,
    unit_price NUMERIC(12,2),
    revenue NUMERIC(18,2)
);

INSERT INTO dw.fact_sales_elt (
    date_key, product_key, customer_key, order_id, quantity, unit_price, revenue
)
SELECT
    TO_CHAR(o.order_date::date, 'YYYYMMDD')::int AS date_key,
    dp.product_key,
    dc.customer_key,
    o.order_id::int,
    rs.quantity::int,
    -- Fix negative prices inline
    CASE WHEN rs.unit_price::numeric <= 0 THEN 10.00 ELSE rs.unit_price::numeric END AS unit_price,
    -- Calculate revenue
    (rs.quantity::int * 
     CASE WHEN rs.unit_price::numeric <= 0 THEN 10.00 ELSE rs.unit_price::numeric END)::numeric(18,2) AS revenue
FROM dw.raw_sales rs
JOIN staging.stg_order o ON rs.order_id = o.order_id
JOIN dw.dim_product dp ON dp.product_id = rs.product_id::int
JOIN dw.dim_customer dc ON dc.customer_id = o.cutomer_id::int
JOIN dw.dim_date dd ON dd.date_key = TO_CHAR(o.order_date::date, 'YYYYMMDD')::int;

--------TASK 3------
SELECT 
    (SELECT SUM(revenue) FROM dw.fact_sales)::numeric(18,2) AS etl_total_revenue,
    (SELECT SUM(revenue) FROM dw.fact_sales_elt)::numeric(18,2) AS elt_total_revenue;


