DROP SCHEMA IF EXISTS staging CASCADE;
DROP SCHEMA IF EXISTS dw CASCADE;
CREATE SCHEMA staging;
CREATE SCHEMA dw;

----------------- Task 2---------------
CREATE TABLE staging.stg_events (
    event_id INTEGER,
    user_id INTEGER,
    title_id INTEGER,
    platform_id INTEGER,
    event_type TEXT DEFAULT 'UNKNOWN',
    event_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    scene_id decimal DEFAULT 0,
    duration_seconds NUMERIC DEFAULT 0,
    sentiment_score NUMERIC DEFAULT 0
);

CREATE TABLE staging.stg_users (
    user_id INTEGER,
    signup_date DATE,
    age_band TEXT,
    country TEXT,
    region TEXT
);

CREATE TABLE staging.stg_titles (
    title_id INTEGER,
    title_name TEXT,
    author_or_director TEXT,
    medium TEXT,
    release_year INTEGER
);

CREATE TABLE staging.stg_platforms (
    platform_id INTEGER,
    platform_name TEXT
);

CREATE TABLE staging.stg_event_types (
    event_type TEXT
);

------------------------ Section B ---------------------

------------ Q1 --------------
CREATE TABLE dw.dim_title (
    title_key SERIAL PRIMARY KEY,
    title_id INTEGER UNIQUE,
    title_name TEXT,
    author_or_director TEXT,
    medium TEXT,
    release_year INTEGER
);

CREATE TABLE dw.dim_user (
    user_key SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE,
    signup_date DATE,
    age_band TEXT,
    country TEXT,
    region TEXT
);

CREATE TABLE dw.dim_platform (
    platform_key SERIAL PRIMARY KEY,
    platform_id INTEGER UNIQUE,
    platform_name TEXT
);

CREATE TABLE dw.dim_event_type (
    event_type_key SERIAL PRIMARY KEY,
    event_type_name TEXT UNIQUE
);

CREATE TABLE dw.dim_datetime (
    datetime_key SERIAL PRIMARY KEY,
    full_ts TIMESTAMP UNIQUE,
    year INTEGER,
    month INTEGER,
    day INTEGER,
    hour INTEGER
);

CREATE TABLE dw.fact_engagement (
    event_id INTEGER,
    datetime_key INTEGER REFERENCES dw.dim_datetime(datetime_key),
    title_key INTEGER REFERENCES dw.dim_title(title_key),
    user_key INTEGER REFERENCES dw.dim_user(user_key),
    platform_key INTEGER REFERENCES dw.dim_platform(platform_key),
    event_type_key INTEGER REFERENCES dw.dim_event_type(event_type_key),
    scene_id INTEGER,
    duration_seconds NUMERIC,
    sentiment_score NUMERIC
);

------------------ Q2 ------------------
INSERT INTO dw.dim_platform (platform_id, platform_name)
SELECT DISTINCT platform_id, INITCAP(platform_name)
FROM staging.stg_platforms;

INSERT INTO dw.dim_title (title_id, title_name, author_or_director, medium, release_year)
SELECT DISTINCT title_id, title_name, author_or_director, UPPER(medium), release_year
FROM staging.stg_titles;

INSERT INTO dw.dim_user (user_id, signup_date, age_band, country, region)
SELECT DISTINCT user_id, signup_date, age_band, country, INITCAP(region)
FROM staging.stg_users;

INSERT INTO dw.dim_event_type (event_type_name)
SELECT DISTINCT event_type
FROM staging.stg_event_types;

INSERT INTO dw.dim_datetime (full_ts, year, month, day, hour)
SELECT DISTINCT event_ts,
    EXTRACT(YEAR FROM event_ts)::INTEGER,
    EXTRACT(MONTH FROM event_ts)::INTEGER,
    EXTRACT(DAY FROM event_ts)::INTEGER,
    EXTRACT(HOUR FROM event_ts)::INTEGER
FROM staging.stg_events;


INSERT INTO dw.fact_engagement (event_id, datetime_key, title_key, user_key, platform_key, event_type_key, scene_id, duration_seconds, sentiment_score)
SELECT 
    e.event_id,
    dd.datetime_key,
    dt.title_key,
    du.user_key,
    dp.platform_key,
    de.event_type_key,
    e.scene_id,
    COALESCE(CASE WHEN e.duration_seconds < 0 THEN 0 ELSE e.duration_seconds END, 0),
    COALESCE(e.sentiment_score, 0)
FROM staging.stg_events e
JOIN dw.dim_datetime dd ON e.event_ts = dd.full_ts
JOIN dw.dim_title dt ON e.title_id = dt.title_id
JOIN dw.dim_user du ON e.user_id = du.user_id
JOIN dw.dim_platform dp ON e.platform_id = dp.platform_id
JOIN dw.dim_event_type de ON e.event_type = de.event_type_name;

------------------ Q3 ----------------
SELECT COUNT(*) FROM staging.stg_events;
SELECT COUNT(*) FROM dw.fact_engagement;

SELECT COUNT(*) FROM dw.fact_engagement 
WHERE datetime_key IS NULL OR title_key IS NULL OR user_key IS NULL OR platform_key IS NULL OR event_type_key IS NULL;

SELECT AVG(duration_seconds), AVG(sentiment_score) FROM dw.fact_engagement;

----------------- Section C ----------------
------------------- Q4 ---------------------
CREATE TABLE dw.raw_events AS
SELECT * FROM staging.stg_events;

-- Q5: Transform Inside DW
CREATE TABLE dw.fact_engagement_elt (
    event_id INTEGER,
    datetime_key INTEGER REFERENCES dw.dim_datetime(datetime_key),
    title_key INTEGER REFERENCES dw.dim_title(title_key),
    user_key INTEGER REFERENCES dw.dim_user(user_key),
    platform_key INTEGER REFERENCES dw.dim_platform(platform_key),
    event_type_key INTEGER REFERENCES dw.dim_event_type(event_type_key),
    scene_id INTEGER,
    duration_seconds NUMERIC,
    sentiment_score NUMERIC
);

INSERT INTO dw.fact_engagement_elt (event_id, datetime_key, title_key, user_key, platform_key, event_type_key, scene_id, duration_seconds, sentiment_score)
SELECT 
    e.event_id,
    dd.datetime_key,
    dt.title_key,
    du.user_key,
    dp.platform_key,
    de.event_type_key,
    e.scene_id,
    COALESCE(CASE WHEN e.duration_seconds < 0 THEN 0 ELSE e.duration_seconds END, 0),
    COALESCE(e.sentiment_score, 0)
FROM dw.raw_events e
JOIN dw.dim_datetime dd ON e.event_ts = dd.full_ts
JOIN dw.dim_title dt ON e.title_id = dt.title_id
JOIN dw.dim_user du ON e.user_id = du.user_id
JOIN dw.dim_platform dp ON e.platform_id = dp.platform_id
JOIN dw.dim_event_type de ON e.event_type = de.event_type_name;

-------------------- Q6 -----------------------
SELECT 
    (SELECT COUNT(*) FROM dw.fact_engagement) AS etl_rows, 
    (SELECT COUNT(*) FROM dw.fact_engagement_elt) AS elt_rows, 
    (SELECT SUM(duration_seconds) FROM dw.fact_engagement) AS etl_sum, 
    (SELECT SUM(duration_seconds) FROM dw.fact_engagement_elt) AS elt_sum;

---------------------- Section D -----------------

------------------------- Q7 ----------------------
SELECT 
    EXTRACT(YEAR FROM d.full_ts) AS year,
    EXTRACT(MONTH FROM d.full_ts) AS month,
    t.medium,
    SUM(f.duration_seconds) / 60.0 AS total_minutes
FROM dw.fact_engagement f
JOIN dw.dim_datetime d ON f.datetime_key = d.datetime_key
JOIN dw.dim_title t ON f.title_key = t.title_key
GROUP BY 
    EXTRACT(YEAR FROM d.full_ts),
    EXTRACT(MONTH FROM d.full_ts),
    t.medium;


------------------------- Q8 -------------------------
SELECT 
    p.platform_name,
    et.event_type_name,
    COUNT(*)
FROM dw.fact_engagement f
JOIN dw.dim_platform p ON f.platform_key = p.platform_key
JOIN dw.dim_event_type et ON f.event_type_key = et.event_type_key
GROUP BY p.platform_name, et.event_type_name;

------------------------- Q9 --------------------------
SELECT 
    t.medium,
    et.event_type_name,
    SUM(f.duration_seconds) AS total_seconds
FROM dw.fact_engagement f
JOIN dw.dim_title t ON f.title_key = t.title_key
JOIN dw.dim_event_type et ON f.event_type_key = et.event_type_key
GROUP BY CUBE(t.medium, et.event_type_name)
ORDER BY t.medium, et.event_type_name;

------------------------ Q10 ---------------------------
CREATE TABLE dw.agg_month_medium AS
SELECT 
    EXTRACT(YEAR FROM d.full_ts)::INTEGER AS year,
    EXTRACT(MONTH FROM d.full_ts)::INTEGER AS month,
    t.medium,
    SUM(f.duration_seconds) AS total_seconds,
    COUNT(*) AS event_count
FROM dw.fact_engagement f
JOIN dw.dim_datetime d ON f.datetime_key = d.datetime_key
JOIN dw.dim_title t ON f.title_key = t.title_key
GROUP BY 1, 2, 3;

select * from dw.agg_month_medium