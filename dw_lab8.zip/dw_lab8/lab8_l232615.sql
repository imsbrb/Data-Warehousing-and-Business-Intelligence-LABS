create schema if not exists bookverse_stg;
create schema if not exists bookverse_dw;

-- staging tables

create table if not exists bookverse_stg.authors (
    author_id integer,
    author_name varchar(255),
    nationality varchar(100)
);

create table if not exists bookverse_stg.books (
    book_id integer,
    title varchar(255),
    genre varchar(100),
    publication_year integer,
    price numeric(10,2),
    author_id integer
);

create table if not exists bookverse_stg.customers (
    cust_id integer,
    customer_name varchar(255),
    region varchar(100)
);

create table if not exists bookverse_stg.sales (
    transaction_id integer,
    cust_id integer,
    book_id integer,
    sale_date date,
    quantity integer,
    revenue numeric(10,2)
);


-- dimension and fact tables

create table if not exists bookverse_dw.dim_author (
    author_key integer generated always as identity primary key,
    author_id integer not null unique,
    author_name varchar(255),
    nationality varchar(100)
);

create table if not exists bookverse_dw.dim_customer (
    cust_key integer generated always as identity primary key,
    cust_id integer not null unique,
    customer_name varchar(255),
    region varchar(100)
);

create table if not exists bookverse_dw.dim_book (
    book_key integer generated always as identity primary key,
    book_id integer not null unique,
    author_key integer not null,
    title varchar(255),
    genre varchar(100),
    publication_year integer,
    price numeric(10,2),
    constraint fk_dim_book_author foreign key (author_key)
        references bookverse_dw.dim_author(author_key)
        on update cascade on delete restrict
);

create table if not exists bookverse_dw.dim_date (
    date_key integer primary key,
    sale_date date not null unique,
    year integer,
    month integer,
    day integer
);

create table if not exists bookverse_dw.fact_sales (
    transaction_key integer generated always as identity primary key,
    transaction_id integer not null unique,
    cust_key integer not null,
    book_key integer not null,
    date_key integer not null,
    quantity integer,
    revenue numeric(10,2),
    constraint fk_fact_cust foreign key (cust_key)
        references bookverse_dw.dim_customer(cust_key)
        on update cascade on delete restrict,
    constraint fk_fact_book foreign key (book_key)
        references bookverse_dw.dim_book(book_key)
        on update cascade on delete restrict,
    constraint fk_fact_date foreign key (date_key)
        references bookverse_dw.dim_date(date_key)
        on update cascade on delete restrict
);

-- load dimensions

insert into bookverse_dw.dim_author (author_id, author_name, nationality)
Select author_id, author_name, nationality
from bookverse_stg.authors
on conflict (author_id) do nothing;

insert into bookverse_dw.dim_customer (cust_id, customer_name, region)
Select cust_id, customer_name, region
from bookverse_stg.customers
on conflict (cust_id) do nothing;

insert into bookverse_dw.dim_book (book_id, author_key, title, genre,
publication_year, price)
Select
    b.book_id,
    da.author_key,
    b.title,
    b.genre,
    b.publication_year,
    b.price
from bookverse_stg.books b
join bookverse_dw.dim_author da on b.author_id = da.author_id
on conflict (book_id) do nothing;

insert into bookverse_dw.dim_date (date_key, sale_date, year, month, day)
Select distinct
    cast(to_char(s.sale_date, 'yyyymmdd') as integer) as date_key,
    s.sale_date,
    extract(year from s.sale_date)::integer as year,
    extract(month from s.sale_date)::integer as month,
    extract(day from s.sale_date)::integer as day
from bookverse_stg.sales s
on conflict (date_key) do nothing;

insert into bookverse_dw.fact_sales (transaction_id, cust_key,
book_key, date_key, quantity, revenue)
Select
    s.transaction_id,
    dc.cust_key,
    db.book_key,
    cast(to_char(s.sale_date, 'yyyymmdd') as integer) as date_key,
    s.quantity,
    s.revenue
from bookverse_stg.sales s
join bookverse_dw.dim_customer dc on s.cust_id = dc.cust_id
join bookverse_dw.dim_book db on s.book_id = db.book_id
join bookverse_dw.dim_date dd on cast(to_char(s.sale_date, 'yyyymmdd')
as integer) = dd.date_key
on conflict (transaction_id) do nothing;


-- indexes

create index if not exists idx_fact_book_key on
bookverse_dw.fact_sales (book_key);
create index if not exists idx_fact_cust_key on
bookverse_dw.fact_sales (cust_key);
create index if not exists idx_fact_date_key on
bookverse_dw.fact_sales (date_key);

create index if not exists idx_dim_book_author_key on
bookverse_dw.dim_book (author_key);
create index if not exists idx_dim_author_author_id on
bookverse_dw.dim_author (author_id);
create index if not exists idx_dim_customer_cust_id on
bookverse_dw.dim_customer (cust_id);


-- pointer map

drop table if exists bookverse_dw.book_author_map;
create table bookverse_dw.book_author_map as
Select book_key, author_key
from bookverse_dw.dim_book;

create index if not exists idx_bam_book_key on
bookverse_dw.book_author_map (book_key);
create index if not exists idx_bam_author_key on
bookverse_dw.book_author_map (author_key);


-- section b: sample queries

explain analyze
Select
    fs.transaction_key,
    fs.revenue,
    dd.sale_date
from bookverse_dw.fact_sales fs
join bookverse_dw.dim_customer dc on fs.cust_key = dc.cust_key
join bookverse_dw.dim_date dd on fs.date_key = dd.date_key
where dc.cust_id = 101
order by dd.sale_date desc
limit 1;

explain analyze
Select
    dc.region,
    sum(fs.revenue) as total_revenue,
    count(fs.transaction_key) as total_transactions
from bookverse_dw.fact_sales fs
join bookverse_dw.dim_customer dc on fs.cust_key = dc.cust_key
group by dc.region
order by total_revenue desc;

-- ===========
-- section c: join type experiments
-- ===========
set local enable_mergejoin = off;
set local enable_hashjoin = off;

explain analyze
Select
    da.author_name,
    sum(fs.revenue) as total_revenue
from bookverse_dw.fact_sales fs
join bookverse_dw.dim_book db on fs.book_key = db.book_key
join bookverse_dw.dim_author da on db.author_key = da.author_key
group by da.author_name
order by total_revenue desc;

set local enable_mergejoin = on;
set local enable_hashjoin = on;

set local enable_hashjoin = off;
set local enable_nestloop = off;

explain analyze
Select
    da.author_name,
    sum(fs.revenue) as total_revenue
from bookverse_dw.fact_sales fs
join bookverse_dw.dim_book db on fs.book_key = db.book_key
join bookverse_dw.dim_author da on db.author_key = da.author_key
group by da.author_name
order by total_revenue desc;

set local enable_hashjoin = on;
set local enable_nestloop = on;

set local enable_mergejoin = off;
set local enable_nestloop = off;

explain analyze
Select
    da.author_name,
    sum(fs.revenue) as total_revenue
from bookverse_dw.fact_sales fs
join bookverse_dw.dim_book db on fs.book_key = db.book_key
join bookverse_dw.dim_author da on db.author_key = da.author_key
group by da.author_name
order by total_revenue desc;

set local enable_mergejoin = on;
set local enable_nestloop = on;

-- pointer-based join
explain analyze
Select
    da.author_name,
    sum(fs.revenue) as total_revenue
from bookverse_dw.fact_sales fs
join bookverse_dw.book_author_map bam on fs.book_key = bam.book_key
join bookverse_dw.dim_author da on bam.author_key = da.author_key
group by da.author_name
order by total_revenue desc;


-- section e: index comparison

explain analyze
Select
    da.author_name,
    sum(fs.revenue) as total_revenue
from bookverse_dw.fact_sales fs
join bookverse_dw.dim_book db on fs.book_key = db.book_key
join bookverse_dw.dim_author da on db.author_key = da.author_key
group by da.author_name
order by total_revenue desc;